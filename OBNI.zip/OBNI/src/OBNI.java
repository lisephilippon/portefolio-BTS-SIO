public class OBNI {

    //Objet Bougeant Non Identifié

    private static final Double DELTA_R = 5.0;

    public String Nom ; //Nom
    public Double X ; //Abscisse
    public Double Y ; //Ordonnée
    public Double R ; //Rayon 

    public void setNom (String Nom) { // mutateur du nom 
        this.Nom = Nom;
    }

    public void setX (Double X) { // mutateur de l'abscisse
        this.X = X;
    }

    public void setY (Double Y) { // mutateur de l'ordonnée
        this.Y = Y;
    }

    public void setR (Double R){ // mutateur du rayon
        this.R = R;
    }    
    
    public String getNom() { // accessseur du nom 
        return Nom;
    }

    public Double getX() { // accesseur de l'abscisse
        return X;
    }

    public Double getY() { // accesseur de l'ordonnée
        return Y;
    }
 
    public Double getR() { // accesseur du rayon
        return R;
    }

    public void deplace(Double dx, Double dy) {  // deplace l'OBNI du double dx et du double dy
        X = X + dx;
        Y = Y + dy;
    }

    public Boolean estPoint() {  // retourne true si l'OBNI est à 00, false sinon
        boolean resultat;
        if (R.equals(0.0)){
            resultat = true;
        }
        else {
            resultat = false;
        }
        return resultat;
    }

    public void grossir_delta() { // augmente le rayon de l'OBNI de DELTA_R
        R = R + DELTA_R;
    }

    public void retrecir_delta() { // diminue le rayon de l'OBNI de DELTA_R
        R = R - DELTA_R;
    }

    public void grossir_auchoix(Double delta) { // augmente le rayon l'OBNI du double choisi
        R = R + delta;
    }

    public void retrecir_auchoix(Double delta) { // diminue le rayon l'OBNI du double choisi
        R = R- delta;
    }

    private Boolean collision(OBNI that) {  //  retourne vrai si et seulement la distance qui sépare cet objet (this) de that est inférieure à la somme de leurs rayons.
         return (Math.sqrt(Math.pow(this.getX() - that.getX(), 2) + 
                Math.pow(this.getY() - that.getY(), 2)) < this.getR() + that.getR());

    }

    public void absorbe(OBNI that) { //en cas de collision entre cet objet (this) et that, cet objet absorbe l’autre. C’est à dire que le rayon de cet objet augmente du rayon de l’autre et le rayon de l’autre passe à zéro.
        if (this.collision(that)) {
            this.setR(this.getR()+that.getR());
            that.setR(0.0);
        }
    }

    public void estAbsorbe(OBNI that) { //même spécifications que la méthode précédente sauf que l’absorption se fait dans l’autre sens.
        if (this.collision(that)) {
            that.setR(this.getR()+that.getR());
            this.setR(0.0);
        }
    }
 
    public OBNI pond() { //produit un nouvel OBNI dont le rayon est la moitié de celui de cet objet
        OBNI oeuf = new OBNI();
        oeuf.X = 0.0;
        oeuf.Y = 0.0;
        oeuf.R = this.R / 2;
        
        return oeuf;
    }

    public OBNI pond(OBNI that) { // même principe que la méthode précédente sauf que la position et le rayon du nouvel objet s’obtiennent en faisant la somme des caractéristiques correspondantes des ”parents”
        OBNI oeuf = new OBNI();
        oeuf.X = this.X + that.X;
        oeuf.Y = this.Y + that.Y;
        oeuf.R = this.R + that.R;
        
        return oeuf;
    }

    public String toString() { // affichage
        return "OBNI {" + "Nom = " + this.getNom() +
        ", X = " + this.getX() + ", Y = " + this.getY() +
        ", R = " + this.getR() + "}";
    }
}
