public class AppOBNI {
    
    public static void main(String[] args) {
    OBNI test1 = new OBNI();
    test1.setNom("Boule"); 
    test1.setX(0.0);
    test1.setY(0.0);
    test1.setR(0.0);
    test1.getNom();
    test1.getX();
    test1.getY();
    test1.getR();
    System.out.println(test1.toString());



    OBNI test2 = new OBNI();
    test2.setNom("Triangle");
    test2.setX(2.0);
    test2.setY(3.0);
    test2.setR(4.0);
    System.out.println(test2.toString());
    test2.deplace(1.0, 2.0);  // deplace
    System.out.println(test2.toString());
    test2.estPoint();
    System.out.println(test2.toString());
    test2.grossir_delta();  //grossir delta
    System.out.println(test2.toString());
    test2.retrecir_auchoix(2.0);
    System.out.println(test2.toString());
    test2.estAbsorbe(test1);
    System.out.println(test2.toString());
    }
}
